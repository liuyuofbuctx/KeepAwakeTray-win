param(
    [switch]$StartOnLogin
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$sourceExe = Join-Path $PSScriptRoot "KeepAwakeTray.exe"
if (-not (Test-Path -LiteralPath $sourceExe)) {
    throw "KeepAwakeTray.exe was not found next to this installer script."
}

$installDir = Join-Path $env:LOCALAPPDATA "KeepAwakeTray"
$installExe = Join-Path $installDir "KeepAwakeTray.exe"
$desktopShortcut = Join-Path ([Environment]::GetFolderPath("Desktop")) "Keep Awake Tray.lnk"
$startupShortcut = Join-Path ([Environment]::GetFolderPath("Startup")) "Keep Awake Tray.lnk"

New-Item -ItemType Directory -Path $installDir -Force | Out-Null
Copy-Item -LiteralPath $sourceExe -Destination $installExe -Force

$shell = New-Object -ComObject WScript.Shell

function New-KeepAwakeShortcut {
    param(
        [string]$Path,
        [string]$Target
    )

    $shortcut = $shell.CreateShortcut($Path)
    $shortcut.TargetPath = $Target
    $shortcut.WorkingDirectory = Split-Path -Parent $Target
    $shortcut.IconLocation = "$Target,0"
    $shortcut.Description = "Start KeepAwakeTray anti-lock helper"
    $shortcut.Save()
}

New-KeepAwakeShortcut -Path $desktopShortcut -Target $installExe

if ($StartOnLogin) {
    New-KeepAwakeShortcut -Path $startupShortcut -Target $installExe
}

Write-Host "Installed KeepAwakeTray to: $installExe"
Write-Host "Desktop shortcut: $desktopShortcut"
if ($StartOnLogin) {
    Write-Host "Start-on-login shortcut: $startupShortcut"
}
