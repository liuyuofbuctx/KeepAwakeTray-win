Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$installDir = Join-Path $env:LOCALAPPDATA "KeepAwakeTray"
$desktopShortcut = Join-Path ([Environment]::GetFolderPath("Desktop")) "Keep Awake Tray.lnk"
$startupShortcut = Join-Path ([Environment]::GetFolderPath("Startup")) "Keep Awake Tray.lnk"

Get-Process -Name "KeepAwakeTray" -ErrorAction SilentlyContinue | Stop-Process -Force

Remove-Item -LiteralPath $desktopShortcut -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $startupShortcut -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $installDir -Recurse -Force -ErrorAction SilentlyContinue

Write-Host "KeepAwakeTray was uninstalled."
