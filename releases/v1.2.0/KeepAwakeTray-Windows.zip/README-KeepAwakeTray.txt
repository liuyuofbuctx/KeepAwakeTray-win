KeepAwakeTray
=============

What it does
------------
KeepAwakeTray is a Windows tray app. When the computer has no keyboard or mouse
input for 8 minutes, it sends a tiny mouse movement with SendInput to reset the
Windows idle timer.

Run without installing
----------------------
Double-click KeepAwakeTray.exe.

Install for the current Windows user
------------------------------------
Right-click Install-KeepAwakeTray.ps1 and choose "Run with PowerShell".

Install and start automatically after login
-------------------------------------------
Open PowerShell in this folder and run:

powershell -ExecutionPolicy Bypass -File .\Install-KeepAwakeTray.ps1 -StartOnLogin

Uninstall
---------
Right-click Uninstall-KeepAwakeTray.ps1 and choose "Run with PowerShell".

Notes
-----
- The app shows a tray icon only; it has no main window.
- Left-click the tray icon to toggle active/paused mode.
- Right-click the tray icon to pause, resume, trigger once, or exit.
- If Windows SmartScreen warns about the file, it is because this local build is
  unsigned.

